package io.github.bdotalot.uptownfuncproject.entities;

import io.github.bdotalot.uptownfuncproject.Main;
import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import io.github.bdotalot.uptownfuncproject.GameState;
public class BasicCharacter {
    float x;
    float y;
    float size;
    float xSpeed;
    float ySpeed;
    boolean controllable;
    Texture lefttexture;
    Texture righttexture;
    float controlSpeed = 5f;
    int maxStamina = 400;
    int currentStamina = maxStamina;
    Texture currentTexture;
    float interactionRate = 40f;
    ArrayList<interactables> interactables;
    public BasicCharacter(float x, float y, float size, float xSpeed, float ySpeed, boolean controllable, float controlSpeed) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
        this.controllable = controllable;
        this.controlSpeed = controlSpeed;
        this.righttexture = new Texture("character.png");
        this.lefttexture = new Texture("leftchar.png");
        // default to left texture after textures are created
        this.currentTexture = this.lefttexture;
    }   

    public void setInteractables(ArrayList<interactables> interactables) {
        this.interactables = interactables;
    }

    public float getX() {
        return x;
    }
    public float getY() {
        return y;
    }
    public float getStamina(){
        return currentStamina;
    }
    public void update(GameState gameState){
        // Stops the character if not in the PLAYING Gamestate
        if (gameState != GameState.PLAYING) {
            return;
        } 
        
        // Allows the character to sprint
        if (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) && currentStamina > 0) {
            controlSpeed = 2f;
            currentStamina -= 3;
        } else if (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) && currentStamina <= 0) {
            controlSpeed = 0.5f;  
        } else {
            controlSpeed = 1f;
            if (currentStamina < maxStamina) {
                currentStamina += 1;
            }
        }

        // Reduces the characters speed and stamina in the bottom left quadrant
        if ((x<360) && (y<360)){
            controlSpeed = 0.5f;
            
            if (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) && currentStamina > 0){
            controlSpeed = 0.8f;
            currentStamina -= 2;
            }
            if ( Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) && currentStamina <= 0){
            controlSpeed = 0.5f;
            currentStamina -= 1;
            } 
        }

        float dx = 0f;
        float dy = 0f;
        
        //Character controls
        if (Gdx.input.isKeyPressed(Input.Keys.A) || Gdx.input.isKeyPressed(Input.Keys.NUMPAD_4)){
            currentTexture = lefttexture;
            dx -= controlSpeed;
        } 
        if (Gdx.input.isKeyPressed(Input.Keys.D) || Gdx.input.isKeyPressed(Input.Keys.NUMPAD_6)){
            currentTexture = righttexture;
            dx += controlSpeed;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.W) || Gdx.input.isKeyPressed(Input.Keys.NUMPAD_8)) dy += controlSpeed;
        if (Gdx.input.isKeyPressed(Input.Keys.S) || Gdx.input.isKeyPressed(Input.Keys.NUMPAD_2)) dy -= controlSpeed;
        if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
            interactWithNearbyObjects();
        }
        x += dx;
        y += dy;

    }
    public void draw(SpriteBatch batch) {
      
        float width = size * 2f;
        float height = size * 2f;
        // be defensive: fall back to lefttexture if currentTexture somehow null
        Texture tex = (currentTexture != null) ? currentTexture : lefttexture;
        batch.draw(tex, x - width/2f, y - height/2f, width, height);
    }

    
    public void collision(float rx, float ry, float rw, float rh) {
        float closestX = clamp(x, rx, rx + rw);
        float closestY = clamp(y, ry, ry + rh);
        float dx = x - closestX;
        float dy = y - closestY;
        float dist2 = dx*dx + dy*dy;
        float r = size;
        if (dist2 < r*r) {
            float dist = (float)Math.sqrt(dist2);
            if (dist == 0f) {
                float rectCenterX = rx + rw/2f;
                float rectCenterY = ry + rh/2f;
                if (Math.abs(x - rectCenterX) > Math.abs(y - rectCenterY)) {
                    if (x > rectCenterX) x = rx + rw + r; else x = rx - r;
                } else {
                    if (y > rectCenterY) y = ry + rh + r; else y = ry - r;
                }
            } else {
                float overlap = r - dist;
                x += (dx / dist) * overlap;
                y += (dy / dist) * overlap;
            }
        }
    }
    private float clamp(float v, float min, float max) {
        if (v < min) return min;
        if (v > max) return max;
        return v;
    }

    private boolean canInteract(interactables obj) {
        
        float dx = x - obj.getX();
        float dy = y - obj.getY();
        float distance2 = dx*dx + dy*dy;
        float interactionDistance = size + interactionRate;
        return distance2 <= interactionDistance * interactionDistance;
    }

    private void interactWithNearbyObjects() {
        for (interactables obj : Main.instance.worldManager.getInteractableObjects()) {
            if (canInteract(obj)) {
                obj.playerInteraction(this);
            }
        }
    }

    public float getCurrentStamina() {
        return currentStamina;
    }

    public void setCurrentStamina(float stamina) {
        this.currentStamina = (int)stamina;
    }

    public float getMaxStamina() {
        return maxStamina;
    }

    public void setMaxStamina(float maxStamina) {
        this.maxStamina = (int)maxStamina;
    }
}
