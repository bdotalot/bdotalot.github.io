package io.github.bdotalot.uptownfuncproject.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public interface interactables {
    void playerInteraction(BasicCharacter player);
    void render(SpriteBatch batch);
    float getX();
    float getY();
    float getWidth();
    float getHeight();
}
