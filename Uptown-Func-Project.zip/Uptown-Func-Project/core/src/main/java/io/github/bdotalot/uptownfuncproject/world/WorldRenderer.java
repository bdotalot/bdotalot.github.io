package io.github.bdotalot.uptownfuncproject.world;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

import io.github.bdotalot.uptownfuncproject.GameCamera;
import io.github.bdotalot.uptownfuncproject.entities.BasicCharacter;
import io.github.bdotalot.uptownfuncproject.entities.interactables;
import io.github.bdotalot.uptownfuncproject.entities.wall;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.List;

public class WorldRenderer {
    private GameCamera camera;
    private BasicCharacter player;
    private List<interactables> interactableObjects;
    private ShapeRenderer fog;
    private int tileSize;
    private boolean[][] revealedTiles;

    public WorldRenderer(GameCamera camera, BasicCharacter player, List<interactables> interactableObjects,ShapeRenderer fog, int tileSize, boolean[][] revealedTiles) {
        this.camera = camera;
        this.player = player;
        this.interactableObjects = interactableObjects;
        this.fog = fog;
        this.tileSize = tileSize;
        this.revealedTiles = revealedTiles;
    }

    //Main game rendering
    public void render(SpriteBatch batch, float delta) {
        batch.setProjectionMatrix(camera.getCam().combined);
        batch.begin();
    
        //render interactable objects
        for (interactables obj : interactableObjects) {
            obj.render(batch);
            if (obj instanceof wall) {
                wall w = (wall) obj;
                player.collision(w.getX(), w.getY(), w.getWidth(), w.getHeight());
            }
        }

        //render player
        player.draw(batch);

        batch.end();
        // Render fog on the map

        fog.setProjectionMatrix(camera.getCam().combined);
        fog.begin(ShapeRenderer.ShapeType.Filled);
        fog.setColor(0,0,0,0.8f);
        for (int i = 0; i < revealedTiles.length; i++) {
            for (int j = 0; j < revealedTiles[0].length; j++) {
                if (revealedTiles[i][j] == false) {
                    fog.rect(j * tileSize, i * tileSize, tileSize, tileSize);
                }
            }
        }
        fog.end();
       
    }
    
}
