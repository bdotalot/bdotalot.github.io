package io.github.bdotalot.uptownfuncproject;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.MathUtils;
public class GameCamera{
	private OrthographicCamera cam;
	private boolean mapView = false;
	
    static final int WORLD_WIDTH = 720;
	static final int WORLD_HEIGHT = 720;

    public void create() {

		cam = new OrthographicCamera(30, 30 * (Gdx.graphics.getHeight() / (float)Gdx.graphics.getWidth()));
		cam.zoom = 8f;
		cam.update();
    }

	// Update camera position based on player position and map view state
    public void update(float playerX, float playerY, boolean mapView) {
		if (!mapView) {
			cam.position.set(playerX, playerY, 0);
		} else {
			cam.position.set(360, 360, 0);
		}
	
		cam.position.x = MathUtils.clamp(cam.position.x, 0, 720);
		cam.position.y = MathUtils.clamp(cam.position.y, 0, 720);
        cam.update();
    }

	// Adjust camera viewport on window resize
    public void resize(int width, int height) {
        cam.viewportWidth = 30;
        cam.viewportHeight = 30 * height / (float) width;
        cam.update();
    }

	// Set camera view mode based on map view state
	public void setMapView(boolean mapView, float playerX, float playerY) {
		if (mapView == false) {
			cam.position.set(playerX, playerY, 0);
			cam.zoom = 8f;
		} else if (mapView == true) {
			cam.position.set(360, 360, 0);
			cam.zoom = 45f;
		}
		cam.update();
	}

    public OrthographicCamera getCam() {
        return cam;
    }

	public boolean isMapView() {
		return mapView;
	}
}
