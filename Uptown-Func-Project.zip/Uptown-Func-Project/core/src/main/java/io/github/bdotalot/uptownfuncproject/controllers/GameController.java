package io.github.bdotalot.uptownfuncproject.controllers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.scenes.scene2d.Stage;

import io.github.bdotalot.uptownfuncproject.GameCamera;
import io.github.bdotalot.uptownfuncproject.GameState;
import io.github.bdotalot.uptownfuncproject.UI.LoseScreen;
import io.github.bdotalot.uptownfuncproject.UI.PauseMenu;
import io.github.bdotalot.uptownfuncproject.entities.BasicCharacter;

public class GameController {
    private GameState state;
    private GameCamera camera;
    private GameTimer gameTimer;
    private PauseMenu pauseMenu;
    private Stage uiStage;

    public GameController(GameState state, GameCamera camera, GameTimer gameTimer, PauseMenu pauseMenu, Stage uiStage) {
        this.state = state;
        this.camera = camera;
        this.gameTimer = gameTimer;
        this.pauseMenu = pauseMenu;
        this.uiStage = uiStage;
    }

    //Changes the different GameStates depending on what key is pressed.
    public GameState update(float playerX, float playerY) {
        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)){
            if (state == GameState.START){
                state = GameState.PLAYING;
            }
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.TAB)){
            if (state == GameState.PLAYING) {
                state = GameState.MAP;
                camera.setMapView(true, playerX, playerY);
            } else if (state == GameState.MAP) {
                state = GameState.PLAYING;
                camera.setMapView(false, playerX, playerY);
            }
        }
       

        if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            if (state != GameState.PAUSED) {
                state = GameState.PAUSED;
                gameTimer.pause();
                pauseMenu.show();
                Gdx.input.setInputProcessor(uiStage);
            } else {
                state = GameState.PLAYING;
                gameTimer.resume();
                pauseMenu.hide();
                Gdx.input.setInputProcessor(null);
            }
        }
        

        return state;
    }

    //Updates the timer at the top and will automatically go to the lose state if timer is 0
    public GameState updateLoseTimer(float delta, BasicCharacter player, LoseScreen loseScreen, GameTimer timer, Stage uiStage) {
        if (state == GameState.PLAYING) {
            camera.update(player.getX(), player.getY(), false);
            timer.update(delta);

            if (timer.getSeconds() <= 0) {
                state = GameState.LOSE;
                loseScreen.show();
                Gdx.input.setInputProcessor(uiStage);
            }
        }

        return state;
    }

    public void setPauseMenu(PauseMenu pauseMenu) {
        this.pauseMenu = pauseMenu;
    }

    public void setState(GameState state) {
        this.state = state;
    }
}
