package io.github.bdotalot.uptownfuncproject.controllers;

public class GameTimer {
    private float seconds;
    private boolean isPaused;

    public GameTimer(float startTime) {
        this.seconds = startTime;
    }

    public void update(float deltaTime) {
        if (isPaused) return;
        seconds -= deltaTime;
        if (seconds < 0) {
            seconds = 0;
        }
    }

    public void pause() {
        isPaused = true;
    }

    public void resume() {
        isPaused = false;
    }

    public boolean isFinished() {
        return seconds <= 0f;
    }

    public String formatTime() {
        int totalSeconds = (int) Math.ceil(seconds);
        int minutesFormatted = totalSeconds / 60;
        int secondsFormatted = totalSeconds % 60;
        return String.format("%d:%02d", minutesFormatted, secondsFormatted);
    }

    public float getSeconds() {
        return seconds;
    }
}
