package io.github.bdotalot.uptownfuncproject;
import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ExtendViewport;

import io.github.bdotalot.uptownfuncproject.UI.HUDRenderer;
import io.github.bdotalot.uptownfuncproject.UI.LoseScreen;
import io.github.bdotalot.uptownfuncproject.UI.PauseMenu;
import io.github.bdotalot.uptownfuncproject.UI.StartScreen;
import io.github.bdotalot.uptownfuncproject.UI.WinScreen;
import io.github.bdotalot.uptownfuncproject.controllers.GameController;
import io.github.bdotalot.uptownfuncproject.controllers.GameTimer;
import io.github.bdotalot.uptownfuncproject.entities.BasicCharacter;
import io.github.bdotalot.uptownfuncproject.entities.interactables;
import io.github.bdotalot.uptownfuncproject.world.GameWorld;
import io.github.bdotalot.uptownfuncproject.world.PopUpManager;
import io.github.bdotalot.uptownfuncproject.world.WorldRenderer;

public class Main extends ApplicationAdapter {
    private SpriteBatch batch;
    private Texture image;
    private GameCamera camera;
    private OrthographicCamera uiCamera;
    private BasicCharacter player;
    private ShapeRenderer bar;
    private ShapeRenderer fog;
    private BitmapFont font;
    private Label objectLabel;

    private final int tileSize = 20;

    private Stage uiStage;
    private Label timerLabel;
    private PauseMenu pauseMenu;
    private WinScreen winScreen;
    private LoseScreen loseScreen;
    private StartScreen startScreen;
    private BitmapFont uiFont;
    private Texture uiBgTexture;
    private GameTimer timer;
    public GameState state = GameState.START;

    public PopUpManager popup;
    public GameWorld worldManager;
    public WorldRenderer worldRenderer;
    private HUDRenderer hudRenderer;
    private GameController gameController;

    public static Main instance;


    @Override
    public void create() {
        instance = this;

        // Initalises all the different files ETC.
        worldManager = new GameWorld();
        batch = new SpriteBatch();
        font = new BitmapFont();
        bar = new ShapeRenderer();
        fog = new ShapeRenderer();
       
        // Initialize camera
        camera = new GameCamera();
        camera.create();
        uiCamera = new OrthographicCamera();
        uiCamera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        // Initialize player
        player = new BasicCharacter(8,
        670,
        10, // size (radius)
        0, 0,
        true, // controllable
        3 // control speed
        );


        worldRenderer = new WorldRenderer(camera, player, worldManager.getInteractableObjects(), fog, tileSize, worldManager.getRevealedTiles());
        worldManager.defaultInteractableObjects();

        // Creating the game Timer and the Object counter

        uiStage = new Stage(new ExtendViewport(800 * 16/9f, 800));
        timer = new GameTimer(300f);
    
        Pixmap px = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        px.setColor(Color.BLACK);
        px.fill();
        uiBgTexture = new com.badlogic.gdx.graphics.Texture(px);
        px.dispose();

        uiFont = new BitmapFont();
        uiFont.getData().setScale(2.5f);
        LabelStyle style = new LabelStyle(uiFont, Color.WHITE);
        style.background = new TextureRegionDrawable(new TextureRegion(uiBgTexture));
        timerLabel = new Label(timer.formatTime(), style);
        uiFont.getData().setScale(1.5f);
        LabelStyle styletwo = new LabelStyle(uiFont, Color.WHITE);
        objectLabel = new Label("", styletwo);
        uiStage.addActor(timerLabel);
        uiStage.addActor(objectLabel);

        hudRenderer = new HUDRenderer(uiCamera, player);
        gameController = new GameController(state, camera, timer, pauseMenu, uiStage);

        pauseMenu = new PauseMenu(uiStage, style, () -> {
            state = GameState.PLAYING;
            gameController.setState(GameState.PLAYING);
            timer.resume();
            pauseMenu.hide();
            Gdx.input.setInputProcessor(null);
        }, () -> Gdx.app.exit());

        gameController.setPauseMenu(pauseMenu);

        startScreen = new StartScreen(uiStage, style); 
        winScreen = new WinScreen(uiStage, style);
        loseScreen = new LoseScreen(uiStage, style);

        timerLabel.setVisible(false);
        objectLabel.setVisible(false);

        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("PressStart2P.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter smallFontParam = new FreeTypeFontGenerator.FreeTypeFontParameter();
        smallFontParam.size = 8;
        BitmapFont smallFont = generator.generateFont(smallFontParam);
        popup = new PopUpManager(smallFont);
        generator.dispose();
    }

    @Override
    public void render() {
        if (state == GameState.START){
            startScreen.show();
        } else {
            startScreen.hide();
        }

        // Update camera position based on game state
        if (state == GameState.PLAYING) {
           camera.getCam().position.set(player.getX(), player.getY(), 0);
        } 
        if (state == GameState.MAP) {
            camera.update(player.getX(), player.getY(), true);
        } else {
            camera.update(player.getX(), player.getY(), false);
        }
        uiCamera.update();
        float delta = Gdx.graphics.getDeltaTime();

        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        if (state != GameState.WIN && state != GameState.LOSE) {
            state = gameController.update(player.getX(), player.getY());
            state = gameController.updateLoseTimer(delta, player, loseScreen, timer, uiStage);
        }


        //Main game rendering
        worldRenderer.render(batch, delta);

        batch.setProjectionMatrix(camera.getCam().combined);
        batch.begin();
        
        //render player
        float cameraWidth = camera.getCam().viewportWidth * camera.getCam().zoom;
        float cameraHeight = camera.getCam().viewportHeight * camera.getCam().zoom;
        if (state == GameState.PLAYING) {
            player.update(instance.state);

            // Collisions blocking entrance and exit
            player.collision(0, 670, 1, 20);
            player.collision(0,60,20,20);

            player.setInteractables(worldManager.getInteractableObjects());

            int xWidthInTiles = (int)(cameraWidth / tileSize) /2;
            int yHeightInTiles = (int)(cameraHeight / tileSize) /2;
            worldManager.revealTiles(player.getX(), player.getY(), xWidthInTiles, yHeightInTiles);
        } 
    
        // Remove objects that need to be removed
        for (interactables objToRemove : worldManager.getObjectsToRemove()) {
            worldManager.getInteractableObjects().remove(objToRemove);
        }
        worldManager.getObjectsToRemove().clear();

        // Render popup message if active
        popup.render(batch, delta);
        

        batch.end();

        // Rendering HUD
        if (state == GameState.PLAYING) {
            hudRenderer.render(batch);
            hudRenderer.rendertimer(timerLabel);
            hudRenderer.renderObjScore(objectLabel, worldManager.getObjectsInteractedWith());
        } 

        uiStage.act(delta);
        uiStage.draw();
    }

    @Override
    public void resize(int width, int height) {
        uiCamera.setToOrtho(false, width, height);
        camera.resize(width, height);
        uiStage.getViewport().update(width, height, true);
    }

    public static void TriggerWinCondition() {
        instance.state = GameState.WIN;
        instance.timer.pause();
        instance.winScreen.show();
        Gdx.input.setInputProcessor(instance.uiStage);
    }

    public BasicCharacter getPlayer() {
        return player;
    }

    public GameTimer getTimer() {
        return timer;
    }

    public Stage getUIStage(){
        return uiStage;
    }

    @Override
    public void dispose() {
        batch.dispose();
        image.dispose();
        font.dispose();
        bar.dispose();
       
        if (uiStage != null) uiStage.dispose();
        if (uiFont != null) uiFont.dispose();
    }

    
}