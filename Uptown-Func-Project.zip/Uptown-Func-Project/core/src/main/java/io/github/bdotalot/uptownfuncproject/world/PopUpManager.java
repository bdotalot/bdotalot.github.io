package io.github.bdotalot.uptownfuncproject.world;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;;

public class PopUpManager {
    private boolean showPopup = false;
    private String popupText = "";
    private float popupDuration = 2f;
    private float popupX;
    private float popupY;

    private final BitmapFont font;
    private ShapeRenderer shapeRenderer;

    

    public PopUpManager(BitmapFont font) {
        this.font = font;
        this.shapeRenderer = new ShapeRenderer();
    }

    public void showPopup(String text, float x, float y) {
        this.popupText = text;
        this.popupX = x;
        this.popupY = y;
        this.showPopup = true;
        this.popupDuration = 2f; // Reset duration
    }

    // Makes the popup above the object when it has been interacted with
    public void render(SpriteBatch batch, float delta) {
         if (showPopup) {
            popupDuration -= delta;
            if (popupDuration <= 0) {
                showPopup = false;
                return;
            }

            font.getData().setScale(0.35f);

            GlyphLayout layout = new GlyphLayout(font, popupText);
            float textWidth = layout.width;
            float textHeight = layout.height;

            float drawX = popupX - (textWidth / 2f);
            float drawY = popupY + 20f;

            float backgroundX = drawX - 2f;
            float backgroundY = drawY - textHeight - 2f;
            float backgroundWidth = textWidth + 4f;
            float backgroundHeight = textHeight + 4f;

            batch.end();
            shapeRenderer.setProjectionMatrix(batch.getProjectionMatrix());
            shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
            shapeRenderer.setColor(Color.DARK_GRAY);
            shapeRenderer.rect(backgroundX, backgroundY, backgroundWidth, backgroundHeight);
            shapeRenderer.end();
            batch.begin();

            font.draw(batch, popupText, drawX, drawY);
            font.getData().setScale(1f);
            
        }
    }

    public boolean isShowingPopup() {
        return showPopup;
    }

    public void dispose(){
        shapeRenderer.dispose();
    }

}
