package io.github.bdotalot.uptownfuncproject.UI;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;

public class PauseMenu {
    
    private final Table table;
    private final Table controlsTable;
    private final Stage stage;

    public PauseMenu(Stage stage, LabelStyle style, Runnable onResume, Runnable onQuit) {
        this.stage = stage;
        table = new Table();
        table.setFillParent(true);
        table.center();

        Label resume = new Label("Resume", style);
        Label controls = new Label("Controls", style);
        Label quit = new Label("Quit", style);

        resume.setTouchable(Touchable.enabled);
        controls.setTouchable(Touchable.enabled);
        quit.setTouchable(Touchable.enabled);

        resume.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                onResume.run();
            }
        });

        controls.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                showControls();
            }
        });

        quit.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                onQuit.run();
            }
        });

        float buttonWidth = stage.getViewport().getWorldHeight() * 0.25f;
        table.add(resume).width(buttonWidth).pad(16);
        table.row().padTop(20);
        table.add(controls).width(buttonWidth).pad(16);
        table.row().padTop(20);
        table.add(quit).width(buttonWidth).pad(16);

        table.setVisible(false);
        stage.addActor(table);

        // Controls screen
        controlsTable = new Table();
        controlsTable.setFillParent(true);
        controlsTable.center();

        Label controlsText = new Label("WASD - Move\nE - Pick up/Interact\nShift - Sprint\nTab - Map", style);
        controlsText.setTouchable(Touchable.disabled);
        
        Label returnButton = new Label("Return to menu", style);
        returnButton.setTouchable(Touchable.enabled);
        returnButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                hideControls();
            }
        });
 
        controlsTable.add(controlsText).pad(20).center();
        controlsTable.row().padTop(30);
        controlsTable.add(returnButton).pad(16).center();

        controlsTable.setVisible(false);
        stage.addActor(controlsTable);
    }

    private void showControls() {
        table.setVisible(false);
        controlsTable.setVisible(true);
    }

    private void hideControls() {
        controlsTable.setVisible(false);
        table.setVisible(true);
    }

    public void show() {
        table.setVisible(true);
    }

    public void hide() {
        table.setVisible(false);
        controlsTable.setVisible(false);
    }

    public boolean isVisible() {
        return table.isVisible();
    }

    public Stage getStage() {
        return stage;
    }

}
