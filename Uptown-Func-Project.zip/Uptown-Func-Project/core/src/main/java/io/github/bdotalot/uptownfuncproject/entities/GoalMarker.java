package io.github.bdotalot.uptownfuncproject.entities;

import io.github.bdotalot.uptownfuncproject.Main;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GoalMarker implements interactables {
    private float x;
    private float y;
    private float width;
    private float height;
    private Texture texture;

    public GoalMarker(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.texture = new Texture("bus.png"); // Placeholder texture

    }


    @Override
    public void playerInteraction(BasicCharacter player) {
        Main.TriggerWinCondition();
    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(texture, x, y, width, height);
    }

    @Override
    public float getX() {
        return x;
    }

    @Override
    public float getY() {
        return y;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public float getHeight() {
        return height;
    }
    
}
