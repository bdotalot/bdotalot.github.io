package io.github.bdotalot.uptownfuncproject.UI;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;

public class LoseScreen {
    private Stage stage;
    private Table table;
    private Label messageLabel;

    public LoseScreen(Stage stage, LabelStyle style) {
        this.stage = stage;
        
        table = new Table();
        table.setFillParent(true);
        
        messageLabel = new Label("You lose!", style);
        messageLabel.setFontScale(3.0f);
        
        table.add(messageLabel).center();
        table.setVisible(false);
        
        stage.addActor(table);
    }

    public void show() {
        table.setVisible(true);
    }

    public void hide() {
        table.setVisible(false);
    }
}