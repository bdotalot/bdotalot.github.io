package io.github.bdotalot.uptownfuncproject.entities;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class wall implements interactables {
    private float x;
    private float y;
    private float width;
    private float height;
    private Texture wallTexture;

    public wall(float x, float y, float width, float height, Texture wallTexture) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.wallTexture = wallTexture;
        Pixmap pix = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        pix.setColor(Color.WHITE);
        pix.fill();
        
        //wallTexture = new Texture(pix);
        pix.dispose();
    }

    @Override
    public void playerInteraction(BasicCharacter player) {
        // Walls do not have any interaction
    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(wallTexture, x, y, width, height);
    }

    @Override
    public float getX() {
        return x;
    }

    @Override
    public float getY() {
        return y;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public float getHeight() {
        return height;
    }

    public void dispose() {
        wallTexture.dispose();
    }
}
