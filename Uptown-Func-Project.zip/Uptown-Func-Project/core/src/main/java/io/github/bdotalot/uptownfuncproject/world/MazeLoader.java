package io.github.bdotalot.uptownfuncproject.world;

import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.Gdx;

public class MazeLoader {

    public static int[][] loadMaze(String path) {
        String fileData = Gdx.files.internal(path).readString().trim();
        String[] lines = fileData.split("\r?\n"); // handle both \n and \r\n

        List<String> cleanLines = new ArrayList<>();
        for (String line : lines) {
            String trimmed = line.trim();
            if (!trimmed.isEmpty()) {
                cleanLines.add(trimmed);
            }
        }

        int height = cleanLines.size();
        int width = cleanLines.get(0).length();
        int[][] maze = new int[height][width];

        for (int y = 0; y < height; y++) {
            String line = cleanLines.get(y);
            for (int x = 0; x < width; x++) {
                char c = (x < line.length()) ? line.charAt(x) : '1'; // pad with wall if short
                maze[y][x] = (c == '1') ? 1 : 0;
            }
        }

        return maze;
    }
}
