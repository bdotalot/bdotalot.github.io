package io.github.bdotalot.uptownfuncproject.entities;

import io.github.bdotalot.uptownfuncproject.Main;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Food implements interactables {
    private float x;
    private float y;
    private Texture textureOne;
    private int width;
    private int height;


    public Food(float x, float y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.textureOne = new Texture("food.png"); // Placeholder texture
    }

    @Override
    public void playerInteraction(BasicCharacter player) {
        float popupX = this.x + this.width / 2;
        float popupY = this.y + this.height / 2;
        int randomIncrease = (int)(Math.random() * 30) + 20;
        Main.instance.getPlayer().setCurrentStamina(Main.instance.getPlayer().getCurrentStamina() + randomIncrease);
        Main.instance.getPlayer().setMaxStamina(Main.instance.getPlayer().getMaxStamina() + randomIncrease);
        Main.instance.worldManager.removeObject(this);
        Main.instance.popup.showPopup("You picked up some food! Stamina increased by " + randomIncrease + ".", popupX, popupY);
        Main.instance.worldManager.increaseObjectsInteractedWith();
    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(textureOne, x, y, width, height);
    }

    @Override
    public float getX() {
        return x;
    }

    @Override
    public float getY() {
        return y;
    }

    @Override
    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    
}
