package io.github.bdotalot.uptownfuncproject.UI;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Align;

public class StartScreen {
    private Stage stage;
    private Table table;
    private Label messageLabel;
    private Label titleLabel;
    private Label startLabel;

    public StartScreen(Stage stage, LabelStyle style) {
        this.stage = stage;
        
        table = new Table();
        table.setFillParent(true);
        table.center();

        titleLabel = new Label("RULES", style);
        titleLabel.setFontScale(2.5f);
        titleLabel.setAlignment(Align.center);

        messageLabel = new Label("\nYou have 5 minutes to escape the university through the bus!\nYou can pick up items along the way to help you escape\nBut be careful! There are obstructions within the maze", style);
        messageLabel.setFontScale(2.0f);
        messageLabel.setAlignment(Align.center);

        startLabel = new Label("Press Enter to Start!", style);
        startLabel.setFontScale(2.0f);
        startLabel.setAlignment(Align.center);

        // Layout: controls centered, then gap, then start prompt
        table.add(titleLabel).padBottom(10).center();
        table.row();
        table.add(messageLabel).pad(16).center();
        table.row();
        table.add(startLabel).padTop(20).pad(16).center();

        table.setVisible(false);
        
        stage.addActor(table);
    }

    public void show() {
        table.setVisible(true);
    }

    public void hide() {
        table.setVisible(false);
    }
}
