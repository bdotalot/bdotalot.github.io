package io.github.bdotalot.uptownfuncproject.UI;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.ui.Label;

import io.github.bdotalot.uptownfuncproject.Main;
import io.github.bdotalot.uptownfuncproject.entities.BasicCharacter;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class HUDRenderer {
    private ShapeRenderer bar;
    private BitmapFont font;
    private OrthographicCamera uiCamera;
    private BasicCharacter player;
    
    public HUDRenderer(OrthographicCamera uiCamera, BasicCharacter player) {
        this.bar = new ShapeRenderer();
        this.font = new BitmapFont();
        this.uiCamera = uiCamera;
        this.player = player;
    }

    public void render(SpriteBatch batch) {
        // Set up the UI camera

        batch.setProjectionMatrix(uiCamera.combined);
        bar.setProjectionMatrix(uiCamera.combined);

        //Drawing the Stamina Bar at the top Left
        batch.begin();
        font.draw(batch, "Stamina", 80, Gdx.graphics.getHeight() - 10);
        batch.end();

        bar.begin(ShapeRenderer.ShapeType.Filled);
        float barWidth = player.getMaxStamina()/2;
        float barHeight = 20;
        float x = 10;
        float y = Gdx.graphics.getHeight() - barHeight - 30;

        bar.setColor(Color.DARK_GRAY);
        bar.rect(x-1, y-1, barWidth +2, barHeight +2);

        bar.setColor(Color.GREEN);
        float staminaWidth = (player.getStamina() / player.getMaxStamina()) * barWidth;
        bar.rect(x, y, staminaWidth, barHeight);
        bar.setColor(Color.GREEN.cpy().mul(0.85f));
        bar.rect(x, y, staminaWidth, barHeight / 2f + barHeight / 4f);
        bar.setColor(Color.GREEN.cpy().mul(0.75f));
        bar.rect(x, y, staminaWidth, barHeight / 2f);
        bar.setColor(Color.GREEN.cpy().mul(0.55f));
        bar.rect(x, y, staminaWidth, barHeight / 4f);
        if (player.getStamina() < 100) {
            bar.setColor(Color.RED);
            bar.rect(x + staminaWidth, y, barWidth - staminaWidth, barHeight);
        }
        bar.end();
    }
    
    // Draws the timer at the top of the screen
    public void rendertimer(Label timerLabel){
        timerLabel.setVisible(true);
        timerLabel.setText(Main.instance.getTimer().formatTime());
        float vw = Main.instance.getUIStage().getViewport().getWorldWidth();
        float vh = Main.instance.getUIStage().getViewport().getWorldHeight();
        timerLabel.pack();
        float margin = vh * 0.05f;
        timerLabel.setPosition((vw - timerLabel.getWidth()) / 2f, vh - timerLabel.getHeight() - margin);
    }

    // Draws the object interacted counter at the top right
    public void renderObjScore(Label objectLabel, int amountInteractedwith){
        objectLabel.setVisible(true);
        objectLabel.setText("Objects interacted with: " + amountInteractedwith);
        float vw = Main.instance.getUIStage().getViewport().getWorldWidth();
        float vh = Main.instance.getUIStage().getViewport().getWorldHeight();
        objectLabel.pack();
        float margin = vh * 0.05f;
        objectLabel.setPosition(vw - objectLabel.getWidth() - margin, vh - objectLabel.getHeight() - margin);
    }

    public void dispose() {
        bar.dispose();
        font.dispose();
    }
}
