package io.github.bdotalot.uptownfuncproject.world;

import com.badlogic.gdx.graphics.Texture;

import io.github.bdotalot.uptownfuncproject.entities.Food;
import io.github.bdotalot.uptownfuncproject.entities.GoalMarker;
import io.github.bdotalot.uptownfuncproject.entities.book;
import io.github.bdotalot.uptownfuncproject.entities.interactables;
import io.github.bdotalot.uptownfuncproject.entities.lake;
import io.github.bdotalot.uptownfuncproject.entities.wall;

import java.util.ArrayList;
import java.util.List;

public class GameWorld {
    public static final int TILE_SIZE = 20;

    private int[][] mazeMap1;
    private int[][] mazeMap2;
    private int[][] mazeMap3;
    private int[][] mazeMap4;

    private boolean[][] revealedTiles;
    private ArrayList<interactables> interactableObjects;
    private List<interactables> objectsToRemove;
    private int objectsInteractedWith = 0;

    private Texture library, computer, lake, accom, floor, water, tarmac, compfloor;

    public GameWorld(){
        interactableObjects = new ArrayList<interactables>();
        objectsToRemove = new ArrayList<interactables>();
        loadTextures();
        loadMazeMaps();
        populateWorld();
    }

    private void loadTextures(){
        library = new Texture("library.png");
        computer = new Texture("computer.png");
        lake = new Texture("lake.png");
        accom = new Texture("accom.png");
        floor = new Texture("floor.png");
        water = new Texture("water.png");
        tarmac = new Texture("tarmac.png");
        compfloor = new Texture("compfloor.png");
    }

    private void loadMazeMaps(){
        mazeMap1 = MazeLoader.loadMaze("LLmaze.txt");
        mazeMap2 = MazeLoader.loadMaze("LRmaze.txt");   
        mazeMap3 = MazeLoader.loadMaze("ULmaze.txt");
        mazeMap4 = MazeLoader.loadMaze("URmaze.txt");

        revealedTiles = new boolean[(mazeMap3.length + mazeMap4.length)][(mazeMap1[0].length + mazeMap3[0].length)];
    }

    // Load mazes into interactable objects
    private void populateWorld(){
        //Bottom left maze
        for (int y = 0; y < mazeMap1.length; y++) {
            for (int x = 0; x < mazeMap1[0].length; x++) {
                if (mazeMap1[y][x] == 1) {
                    interactableObjects.add(new wall(
                        x * TILE_SIZE,
                        (mazeMap1.length - 1 - y) * TILE_SIZE,
                        TILE_SIZE,
                        TILE_SIZE,lake
                    ));
                }
                if (mazeMap1[y][x] == 0) {
                    interactableObjects.add(new lake(
                        x * TILE_SIZE,
                        (mazeMap1.length - 1 - y) * TILE_SIZE,
                        TILE_SIZE,
                        TILE_SIZE,water
                    ));
                }
            }
        }

        //Bottom right maze

        int offsetX = mazeMap1[0].length * TILE_SIZE;
        for (int y = 0; y < mazeMap2.length; y++) {
            for (int x = 0; x < mazeMap2[0].length; x++) {
                if (mazeMap2[y][x] == 1) {
                    interactableObjects.add(new wall(
                        x * TILE_SIZE + offsetX,
                        (mazeMap2.length - 1 - y) * TILE_SIZE,
                        TILE_SIZE,
                        TILE_SIZE,accom
                    ));
                }
                else if (mazeMap2[y][x] == 0) {
                    interactableObjects.add(new lake(
                        x * TILE_SIZE + offsetX,
                        (mazeMap2.length - 1 - y) * TILE_SIZE,
                        TILE_SIZE,
                        TILE_SIZE,tarmac
                    ));
                } 
            }
        }

        //Upper left maze

        int offsetY = mazeMap1.length * TILE_SIZE;
        for (int y = 0; y < mazeMap3.length; y++) {
            for (int x = 0; x < mazeMap3[0].length; x++) {
                if (mazeMap3[y][x] == 1) {
                    interactableObjects.add(new wall(
                        x * TILE_SIZE,
                        (mazeMap3.length - 1 - y) * TILE_SIZE + offsetY,
                        TILE_SIZE,
                        TILE_SIZE,computer
                    ));
                }
                else if (mazeMap3[y][x] == 0) {
                    interactableObjects.add(new lake(
                        x * TILE_SIZE,
                        (mazeMap3.length - 1 - y) * TILE_SIZE + offsetY,
                        TILE_SIZE,
                        TILE_SIZE,compfloor
                    ));
                } 
            }
        }

        //Upper right maze

        for (int y = 0; y < mazeMap4.length; y++) {
            for (int x = 0; x < mazeMap4[0].length; x++) {
                if (mazeMap4[y][x] == 1) {
                    interactableObjects.add(new wall(
                        x * TILE_SIZE + offsetX,
                        (mazeMap4.length - 1 - y) * TILE_SIZE + offsetY,
                        TILE_SIZE,
                        TILE_SIZE,library
                    ));

                }
                else if (mazeMap4[y][x] == 0) {
                    interactableObjects.add(new lake(
                        x * TILE_SIZE + offsetX,
                        (mazeMap4.length - 1 - y) * TILE_SIZE + offsetY,
                        TILE_SIZE,
                        TILE_SIZE,floor
                    ));
                }    
            }
        }
    }

    public ArrayList<interactables> getInteractableObjects() {
        return interactableObjects;
    }

    public List<interactables> getObjectsToRemove() {
        return objectsToRemove;
    }

    public boolean[][] getRevealedTiles() {
        return revealedTiles;
    }
    // Reveal tiles in a area around the player
    public void revealTiles(float x, float y, int xRadius, int yRadius) {
        int centerX = (int)(x / TILE_SIZE);
        int centerY = (int)(y / TILE_SIZE);

        for (int dy = -yRadius; dy <= yRadius; dy++) {
            for (int dx = -xRadius; dx <= xRadius; dx++) {
                int tileX = centerX + dx;
                int tileY = centerY + dy;
                if (tileX < 0 || tileY < 0 || tileX >= revealedTiles[0].length || tileY >= revealedTiles.length) continue;
                revealedTiles[tileY][tileX] = true;
                
            }
        }

    }

    //This is used for the book object to reveal that area of the map
    public void revealArea(int xStart, int yStart, int width, int height) {
        for (int y = yStart; y < yStart + height; y++) {
            for (int x = xStart; x < xStart + width; x++) {
                if (x < 0 || y < 0 || x >= revealedTiles[0].length || y >= revealedTiles.length) continue;
                revealedTiles[y][x] = true;
            }
        }
    }

    public void addInteractableObject(interactables obj) {
        interactableObjects.add(obj);
    }

    // Any objects to be initalised when the program starts
    public void defaultInteractableObjects() {
        addInteractableObject(new GoalMarker(4, 60, 30, 20));
        addInteractableObject(new book(670, 670, 18, 0, 18, 18, 12, 12));
        addInteractableObject(new Food(568,68,12,12));
        addInteractableObject(new Food(88,288,12,12));
        addInteractableObject(new Food(120,580,12,12));
    }

    public void removeObject(interactables obj) {
        objectsToRemove.add(obj);
    }

    public void clearObjectsToRemove() {
        interactableObjects.removeAll(objectsToRemove);
        objectsToRemove.clear();
    }

    public void increaseObjectsInteractedWith(){
        objectsInteractedWith += 1;
    }

    public int getObjectsInteractedWith(){
        return objectsInteractedWith;
    }



    
}
