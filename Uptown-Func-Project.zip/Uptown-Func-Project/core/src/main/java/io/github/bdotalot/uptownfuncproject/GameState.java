package io.github.bdotalot.uptownfuncproject;

public enum GameState {
    PLAYING,
    PAUSED,
    WIN,
    LOSE,
    MAP,
    START
}