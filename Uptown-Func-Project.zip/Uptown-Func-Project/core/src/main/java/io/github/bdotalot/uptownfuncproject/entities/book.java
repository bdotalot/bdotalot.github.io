package io.github.bdotalot.uptownfuncproject.entities;

import io.github.bdotalot.uptownfuncproject.Main;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class book implements interactables {
    private float x;
    private float y;
    private Texture textureOne;
    private int revealX;
    private int revealY;
    private int revealWidth;
    private int revealHeight;
    private int width;
    private int height;


    public book(float x, float y, int revealX, int revealY, int revealWidth, int revealHeight, int width, int height) {
        this.x = x;
        this.y = y;
        this.revealX = revealX;
        this.revealY = revealY;
        this.revealWidth = revealWidth;
        this.revealHeight = revealHeight;
        this.width = width;
        this.height = height;
        this.textureOne = new Texture("book.png"); 
    }

    @Override
    public void playerInteraction(BasicCharacter player) {
        float popupX = this.x + this.width / 2;
        float popupY = this.y + this.height / 2;
        Main.instance.worldManager.revealArea(revealX, revealY, revealWidth, revealHeight);
        Main.instance.worldManager.removeObject(this);
        Main.instance.popup.showPopup("A part of the map has been revealed!", popupX, popupY);
        Main.instance.worldManager.increaseObjectsInteractedWith();
    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(textureOne, x, y, width, height);
    }

    @Override
    public float getX() {
        return x;
    }

    @Override
    public float getY() {
        return y;
    }

    @Override
    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

}
